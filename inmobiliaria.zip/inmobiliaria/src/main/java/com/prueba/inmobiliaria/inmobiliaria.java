package com.prueba.inmobiliaria;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class inmobiliaria extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conexion;
	java.sql.Statement statement;
	ResultSet resulset;
       
	
    public inmobiliaria() {
    	super();
    	conexion = null;
    	statement = null;
    	resulset = null;
    }
    
    public void getConnection() throws ClassNotFoundException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/inmobiliaria", "root", "");
            System.out.println("La conexion a la base de Datos ha sido exitosa");

        } catch (SQLException e) {
        	System.out.println("Error en la conexion a la BD: "+e);
        }

    }
    
    public void CerrarConnection() {
        try {
        	conexion.close();
            System.out.println("Se ha cerrado la base de datos con exito");
        } catch (SQLException e) {
        	System.out.println("Error en la Desconexion a la BD: "+e);
          }
    }
    
    public void ConsultaPersonas(String datos,PrintWriter out) throws ClassNotFoundException {
    	String sentencia = "SELECT p.*,i.nombre as 'nombre_inmueble',h.fecha FROM tbl_persona p JOIN tbl_habitado h ON P.cedula = h.ced_persona JOIN tbl_inmueble i ON i.codigo = h.cod_inmueble WHERE p.nombre LIKE '%"+datos+"%' or p.apellido LIKE '%"+datos+"%' or p.correo LIKE '%"+datos+"%' ORDER BY p.nombre";
        try {
            getConnection();
            statement =  conexion.createStatement();
            resulset = statement.executeQuery(sentencia);
            if(resulset.next()){
            	resulset.beforeFirst();
            	while(resulset.next()) {
                	out.println("<tr>");
                	out.println("<td>"+resulset.getString(1)+"</td>");
                	out.println("<td>"+resulset.getString(2)+"</td>");
                	out.println("<td>"+resulset.getString(3)+"</td>");
                	out.println("<td>"+resulset.getString(4)+"</td>");
                	out.println("<td>"+resulset.getString(5)+"</td>");
                	out.println("<td>"+resulset.getDate(6)+"</td>");
                	out.println("</tr>");
                }
            }else {
            	out.println("<h4>No hay datos que coincidan con el texto = "+datos+"</h4>");
            }
            CerrarConnection();
        } catch (SQLException e) {
        	System.out.println("Error en la Consulta a la BD: "+e);
        }
    }
    
    


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try (PrintWriter out = response.getWriter()) {
			out.print("<!DOCTYPE html>");
			out.print("<html>");
			out.print("<head>");
			out.print("<meta charset=\"UTF-8\" />");
			out.print("<title>Inmobiliaria</title>");
			out.print("<style>");
			out.print("@charset \"ISO-8859-1\";\r\n"
					+ "\r\n"
					+ "      .content {\r\n"
					+ "        height: auto;\r\n"
					+ "        display: flex;\r\n"
					+ "        justify-content: center;\r\n"
					+ "        align-items: center;\r\n"
					+ "        flex-direction: column;\r\n"
					+ "        font-family: sans-serif;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      h1 {\r\n"
					+ "        border-bottom: solid 1px rgb(195, 203, 212);\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      img {\r\n"
					+ "        background-color: rgb(44, 62, 80);\r\n"
					+ "        border-radius: 10px;\r\n"
					+ "        height: 23vh;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      /*Estilos para e input*/\r\n"
					+ "\r\n"
					+ "      .group {\r\n"
					+ "        display: flex;\r\n"
					+ "        line-height: 28px;\r\n"
					+ "        align-items: center;\r\n"
					+ "        position: relative;\r\n"
					+ "        max-width: 190px;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      .input {\r\n"
					+ "        width: 100%;\r\n"
					+ "        height: 40px;\r\n"
					+ "        line-height: 28px;\r\n"
					+ "        padding: 0 1rem;\r\n"
					+ "        padding-left: 2.5rem;\r\n"
					+ "        border: 2px solid transparent;\r\n"
					+ "        border-radius: 8px;\r\n"
					+ "        outline: none;\r\n"
					+ "        background-color: #f3f3f4;\r\n"
					+ "        color: rbg(44, 62, 80);\r\n"
					+ "        transition: 0.3s ease;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      .input::placeholder {\r\n"
					+ "        color: #9e9ea7;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      .input:focus,\r\n"
					+ "      input:hover {\r\n"
					+ "        outline: none;\r\n"
					+ "        border-color: rgba(44, 62, 80, 0.4);\r\n"
					+ "        background-color: #fff;\r\n"
					+ "        box-shadow: 0 0 0 4px rgb(44, 62, 80 / 10%);\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      .icon {\r\n"
					+ "        position: absolute;\r\n"
					+ "        left: 1rem;\r\n"
					+ "        fill: #9e9ea7;\r\n"
					+ "        width: 1rem;\r\n"
					+ "        height: 1rem;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      /* Estilos para el boton */\r\n"
					+ "\r\n"
					+ "      .boton {\r\n"
					+ "        margin: 1rem;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      button {\r\n"
					+ "        appearance: none;\r\n"
					+ "        background-color: transparent;\r\n"
					+ "        border: 0.125em solid #1a1a1a;\r\n"
					+ "        border-radius: 0.9375em;\r\n"
					+ "        box-sizing: border-box;\r\n"
					+ "        color: #3b3b3b;\r\n"
					+ "        cursor: pointer;\r\n"
					+ "        display: inline-block;\r\n"
					+ "        font-family: Roobert, -apple-system, BlinkMacSystemFont, \"Segoe UI\",\r\n"
					+ "          Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\",\r\n"
					+ "          \"Segoe UI Symbol\";\r\n"
					+ "        font-size: 14px;\r\n"
					+ "        font-weight: 600;\r\n"
					+ "        line-height: normal;\r\n"
					+ "        margin: 0;\r\n"
					+ "        min-height: 1.75rem;\r\n"
					+ "        min-width: 0;\r\n"
					+ "        outline: none;\r\n"
					+ "        padding: 10px 3.3rem;\r\n"
					+ "        text-align: center;\r\n"
					+ "        text-decoration: none;\r\n"
					+ "        transition: all 300ms cubic-bezier(0.23, 1, 0.32, 1);\r\n"
					+ "        user-select: none;\r\n"
					+ "        -webkit-user-select: none;\r\n"
					+ "        touch-action: manipulation;\r\n"
					+ "        will-change: transform;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      button:disabled {\r\n"
					+ "        pointer-events: none;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      button:hover {\r\n"
					+ "        color: #fff;\r\n"
					+ "        background-color: rgb(44, 62, 80);\r\n"
					+ "        box-shadow: rgba(44, 62, 80, 0.25) 0 8px 10px;\r\n"
					+ "        transform: translateY(-2px);\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      button:active {\r\n"
					+ "        box-shadow: none;\r\n"
					+ "        transform: translateY(0);\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      /* Estilos para la tabla */\r\n"
					+ "\r\n"
					+ "      table {\r\n"
					+ "        text-align: center;\r\n"
					+ "        table-layout: fixed;\r\n"
					+ "        width: 100%;\r\n"
					+ "        border-collapse: collapse;\r\n"
					+ "        border: 3px solid rgb(44, 62, 80);\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      thead th:nth-child(1) {\r\n"
					+ "        width: 10%;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      thead th:nth-child(2) {\r\n"
					+ "        width: 10%;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      thead th:nth-child(3) {\r\n"
					+ "        width: 5%;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      thead th:nth-child(4) {\r\n"
					+ "        width: 15%;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      th,\r\n"
					+ "      td {\r\n"
					+ "        padding: 10px;\r\n"
					+ "        border: black 1px solid;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      tbody tr:nth-child(odd) {\r\n"
					+ "        background-color: rgb(255, 255, 255);\r\n"
					+ "		font-weight: 1rem;\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      tbody tr:nth-child(even) {\r\n"
					+ "        background-color: rgb(44, 62, 80);\r\n"
					+ "		color: rgb(255,255,255);\r\n"
					+ "      }\r\n");
			out.print("</style>");
			out.print("</head>");
			out.print("<body>");
			out.print("<form action=\"\" method=\"POST\" id=\"formulario\" onsubmit=\"return false;\">");
			out.print("	<div class=\"content\">\r\n"
					+ "		<img alt=\"\" src=\"assets/acrecer.png\" />\r\n"
					+ "		<h1>Consulta de Personas</h1>\r\n"
					+ "		<div class=\"group\">\r\n"
					+ "		  <svg class=\"icon\" aria-hidden=\"true\" viewBox=\"0 0 24 24\">\r\n"
					+ "			<g>\r\n"
					+ "			  <path\r\n"
					+ "				d=\"M21.53 20.47l-3.66-3.66C19.195 15.24 20 13.214 20 11c0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c2.215 0 4.24-.804 5.808-2.13l3.66 3.66c.147.146.34.22.53.22s.385-.073.53-.22c.295-.293.295-.767.002-1.06zM3.5 11c0-4.135 3.365-7.5 7.5-7.5s7.5 3.365 7.5 7.5-3.365 7.5-7.5 7.5-7.5-3.365-7.5-7.5z\"\r\n"
					+ "			  ></path>\r\n"
					+ "			</g>\r\n"
					+ "		  </svg>\r\n"
					+ "		  <input\r\n"
					+ "			class=\"txtBuscar input\"\r\n"
					+ "			name=\"txtBuscar\"\r\n"
					+ "			placeholder=\"texto a Buscar\"\r\n"
					+ "			type=\"search\"\r\n"
					+ "		  />\r\n"
					+ "		</div>\r\n"
					+ "		<div class=\"boton\">\r\n"
					+ "		  <button id=\"btnBuscar\">CONSULTAR</button>\r\n"
					+ "		</div>");
			out.print("</form>");
			
			String texto = request.getParameter("txtBuscar");
			if(texto != null) {
				out.print("<div class=\"content-table\">");
				out.print("<table>");
				out.print("<thead>\r\n"
						+ "			  <tr>\r\n"
						+ "				<th>Cedula</th>\r\n"
						+ "				<th>Nombre</th>\r\n"
						+ "				<th>Apellido</th>\r\n"
						+ "				<th>Correo</th>\r\n"
						+ "				<th>Dirección</th>\r\n"
						+ "				<th>Fecha</th>\r\n"
						+ "			  </tr>\r\n"
						+ "			</thead>");
				out.print("<tbody>");
				//Datos Dinamicos
				ConsultaPersonas(texto,out);
				System.out.println("Hola mundo");
				out.print("</tbody>");
				out.print("</table>");
				out.print("</div>");
				
			}
			out.print("</body>");
			out.print("<script type=\"text/javascript\">");
			out.print(""
					+ " boton = document.getElementById(\"btnBuscar\");\r\n"
					+ "      texto = document.querySelector(\".txtBuscar\");\r\n"
					+ "	    formulario = document.getElementById(\"formulario\");\r\n"
					+ "\r\n"
					+ "      boton.addEventListener(\"click\", MostrarTabla);\r\n"
					+ "\r\n"
					+ "      function MostrarTabla() {\r\n"
					+ "        if (validarDatos()) {\r\n"
					+ "		  formulario.submit();\r\n"
					+ "        }\r\n"
					+ "      }\r\n"
					+ "\r\n"
					+ "      function validarDatos() {\r\n"
					+ "        if (texto.value == \"\") {\r\n"
					+ "          alert(\"Debe ingresar un valor a buscar\");\r\n"
					+ "		  \r\n"
					+ "          return false;\r\n"
					+ "        }\r\n"
					+ "        return true;\r\n"
					+ "      }");
			out.print("</script>");
			out.print("</body>");
			out.print("</html>");
			  
			}//Fin try-catch
 catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
