boton = document.getElementById("btnBuscar");
texto = document.querySelector(".txtBuscar");
tabla = document.querySelector(".content-table");

boton.addEventListener("click", MostrarTabla);

function MostrarTabla() {
	if (validarDatos()) {
	//Remuevo la clase del contenido para mostrar la tabla
		//tabla.classList.remove("content-table");
		location.href = "http://localhost:8090/inmobiliaria/inmobiliaria";
		
        }
      }

function validarDatos() {
   if (texto.value == "") {
       alert("Debe ingresar un valor a buscar");
        return false;
        }
        return true;
      }